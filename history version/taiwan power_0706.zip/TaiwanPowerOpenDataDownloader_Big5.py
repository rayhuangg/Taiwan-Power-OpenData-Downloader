# -*- coding: utf-8 -*-

'''
    每十分鐘定時自動下載台電各機組發電量Open Data, 並轉為Excel可讀取之csv檔案儲存
'''

import requests
import json
import csv
import os
from datetime import date, datetime
import schedule
import time

url = "http://data.taipower.com.tw/opendata01/apply/file/d006001/001.txt"

# 創立資料夾，清理殘留檔案
def cleanfile():
    if not os.path.isdir('csv'):
        os.mkdir('csv')

    if not os.path.isdir('json'):
        os.mkdir('json')

    if os.path.isfile("json/001.json"):
        os.remove("json/001.json")


# 下載txt並轉為json格式
def download():
    cleanfile()
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/103.0.0.0 Safari/537.36"}
    res = requests.get(url, headers=headers)
    res.encoding = 'utf-8'

    print("status_code: ", res.status_code)
    if res.status_code == 200:
        # 利用json loads把檔案轉為json格式，並用dump格式化輸出至文件
        with open("json/001.json", "w", encoding='utf-8') as file:
            json_file = json.loads(res.text)
            json.dump(json_file, file, indent=4, ensure_ascii=False) # 不使用ascii編碼 才能顯示中文


# 建立標題列
def create_title_row_list():
    with open("json/001.json", "r", encoding='utf-8') as json_obj:
        json_data = json.load(json_obj)

    title = [[0] for i in range(2*len(json_data["aaData"])-1)] # 建立空白二維陣列
    title[0] = ["Time"]

    for i in range(1, len(json_data["aaData"])):
        title[i*2-1] = [json_data["aaData"][i][1]]  # 添加發電機組名稱
        title[i*2] = [""]  # 空白欄(機組狀態)

    return title


# 每天建立一個新的csv檔案
def create_csv_file():
    today = date.today()
    filename = today.strftime("%Y_%m_%d")
    
    # 寫入標題欄
    with open(f"csv/{filename}.csv", "w", encoding='Big5', newline='') as csvfile:
        title = create_title_row_list()
        writer = csv.writer(csvfile)
        writer.writerows(title)


# 讀取現有資料轉為列表
def get_csv_content():
    today = date.today()
    filename = today.strftime("%Y_%m_%d")
    with open(f"csv/{filename}.csv", "r", newline='', encoding='Big5') as csvfile:
        current_content = list(csv.reader(csvfile))
        
    return current_content


# 新增當下數據至列表中
def append_current_data_into_list():
    csv_content = get_csv_content()

    with open("json/001.json", "r", encoding='utf-8') as json_obj:
        json_data = json.load(json_obj)

    csv_content[0].append(json_data[""][-5:]) # 目前時間，日期不紀錄

    for i in range(1, len(json_data["aaData"])):
        csv_content[i*2 -1].append(json_data["aaData"][i][3])  # 目前發電量
        csv_content[i*2].append(json_data["aaData"][i][5])     # 機組發電狀況
    
    return csv_content


# 填入內容資料
def fill_in_latest_content():
    today = date.today()
    filename = today.strftime("%Y_%m_%d")
    content = append_current_data_into_list() # 放在外面先行抓取資料 否則open新的csv後便會被覆蓋
    
    with open(f"csv/{filename}.csv", "w", encoding='Big5', newline='') as csvfile:
        writer = csv.writer(csvfile)    
        writer.writerows(content)


# 檢查是否已存在今日的csv檔案，是的話便僅添加資料，否則新創立csv
def check_file_exist():
    
    # 印出現在時間，讓status來做換行
    now = datetime.now()
    current_time = now.strftime("%m%d_%H:%M:%S")
    print(current_time," | ", end="") 

    today = date.today()
    filename = today.strftime("%Y_%m_%d")

    if os.path.isfile(f"csv/{filename}.csv"):
        download()
        fill_in_latest_content()
    else:
        download()
        create_csv_file()
        fill_in_latest_content()


# 設定定時器，每十分鐘執行一次
schedule.every(10).minutes.do(check_file_exist)

# 只執行按下執行的第一次 馬上下載資料
check_file_exist() 

while True:
    schedule.run_pending()
    time.sleep(1)